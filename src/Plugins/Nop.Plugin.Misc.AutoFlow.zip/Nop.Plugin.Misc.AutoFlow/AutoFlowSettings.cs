﻿using Nop.Core.Configuration;

namespace Nop.Plugin.Widgets.AutoFlow
{
    public class AutoFlowSettings : ISettings
    {
        public int CustomRatio { get; set; }
        public int CustomVariable { get; set; }
    }
}