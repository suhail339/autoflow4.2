﻿using System.ComponentModel.DataAnnotations;
using Nop.Web.Framework.Mvc.ModelBinding;
using Nop.Web.Framework.Models;

namespace Nop.Plugin.Widgets.AutoFlow.Models
{
    public class ConfigurationModel : BaseNopModel
    {
        public int CustomRatio { get; set; }
        public int CustomVariable { get; set; }
    }
}