﻿using Nop.Web.Framework.Models;

namespace Nop.Plugin.Widgets.AutoFlow.Models
{
    public class PublicInfoModel : BaseNopModel
    {
        
    }
}