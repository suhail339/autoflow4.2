﻿using Nop.Core;

namespace Nop.Plugin.Widgets.AutoFlow.Domains
{
    public partial class CustomTable : BaseEntity
    {

    }
}
