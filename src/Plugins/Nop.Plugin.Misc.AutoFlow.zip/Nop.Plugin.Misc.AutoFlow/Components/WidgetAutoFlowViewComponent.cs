﻿using Microsoft.AspNetCore.Mvc;
using Nop.Web.Framework.Components;
using System;

namespace Nop.Plugin.Widgets.AutoFlow.Components
{
    [ViewComponent(Name = "WidgetAutoFlow")]
    public class WidgetAutoFlowViewComponent : NopViewComponent
    {
        public WidgetAutoFlowViewComponent()
        {

        }

        public IViewComponentResult Invoke(int productId)
        {
            throw new NotImplementedException();
        }
    }
}
